package com.miaapp.relax

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.miaapp.relax.ui.theme.RelaxTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // installSplashScreen() DEVE essere chiamato prima di super.onCreate()
        val splashScreen = installSplashScreen()

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // ═══════════════════════════════════════════════
        // EXIT ANIMATION DELLA SPLASH
        // ═══════════════════════════════════════════════
        // Quando la Home è pronta, la splash scivola verso l'alto
        // e svanisce in 400 ms.
        //
        // NOTA: `splashScreenView` è di tipo SplashScreenViewProvider,
        // non è una View. La View vera si ottiene con `splashScreenView.view`.
        splashScreen.setOnExitAnimationListener { splashScreenViewProvider ->
            val splashView = splashScreenViewProvider.view

            splashView.animate()
                .translationY(-splashView.height.toFloat())  // scivola verso l'alto
                .alpha(0f)                                    // svanisce
                .setDuration(400L)
                .withEndAction {
                    // Rimuove la splash quando l'animazione è finita
                    splashScreenViewProvider.remove()
                }
                .start()
        }

        setContent {
            RelaxTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    AppNavigazione(innerPadding = innerPadding)
                }
            }
        }
    }
}