package com.miaapp.relax

// ─────────────────────────────────────────────────────────────
// IMPORT
// ─────────────────────────────────────────────────────────────

// Android di base
import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings

// Activity Result (per launcher di permessi e intent)
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke

// Layout Compose
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll

// Icone
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings

// Componenti Material3
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text

// Runtime Compose
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue

// Utility UI
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

// Lifecycle
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

// Utility di sistema
import androidx.core.content.ContextCompat

// Progetto
import com.miaapp.relax.ui.theme.RelaxTheme
import kotlinx.coroutines.launch


// ─────────────────────────────────────────────────────────────
// SCHERMATA HOME
// ─────────────────────────────────────────────────────────────

@Composable
fun SchermataHome(
    onVaiALasciapassare: () -> Unit,
    onVaiAlRegistro: () -> Unit,
    onVaiAInfo: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // ═══════════════════════════════════════════════
    // PERMESSO RUBRICA + PERMESSO NOTIFICHE (concatenati)
    // ═══════════════════════════════════════════════
    var permessoConcesso by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_CONTACTS
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    var richiestaFatta by remember { mutableStateOf(false) }

    // Launcher per il permesso NOTIFICHE.
    // Lo dichiariamo prima, così possiamo richiamarlo dentro
    // la callback del permesso contatti.
    val launcherNotifiche = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* se negato, la notifica non appare: pazienza */ }

    // Launcher per il permesso CONTATTI.
    // Nella callback, DOPO la risposta dell'utente, chiediamo anche
    // il permesso notifiche. (Android non mostra due dialog in contemporanea.)
    val launcherPermesso = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { concesso ->
        permessoConcesso = concesso

        // Chiedi il permesso notifiche solo dopo il permesso contatti
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permessoNotifiche = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!permessoNotifiche) {
                launcherNotifiche.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val launcherImpostazioni = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { /* al ritorno il DisposableEffect ri-controlla il permesso */ }

    LaunchedEffect(Unit) {
        if (!permessoConcesso && !richiestaFatta) {
            richiestaFatta = true
            launcherPermesso.launch(Manifest.permission.READ_CONTACTS)
        }
    }

    // ═══════════════════════════════════════════════
    // RUOLO DI SCREENING CHIAMATE
    // ═══════════════════════════════════════════════
    val sonoAppScreening = ricordaSeSonoAppScreening(context)

    val launcherScreening = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { /* al ritorno il DisposableEffect ri-controlla il ruolo */ }

    // ═══════════════════════════════════════════════
    // LIFECYCLE: ri-controlla permesso a ogni ON_RESUME
    // ═══════════════════════════════════════════════
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permessoConcesso = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_CONTACTS
                ) == PackageManager.PERMISSION_GRANTED
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // ═══════════════════════════════════════════════
    // STATI PREFERENZE (DataStore)
    // ═══════════════════════════════════════════════
    val filtroAttivo by PreferenzeFiltro
        .filtroAttivoFlow(context)
        .collectAsState(initial = false)

    val programmazioneAttiva by PreferenzeFiltro
        .programmazioneAttivaFlow(context)
        .collectAsState(initial = false)

    val tuttoIlGiorno by PreferenzeFiltro
        .tuttoIlGiornoFlow(context)
        .collectAsState(initial = false)

    val oraInizio by PreferenzeFiltro
        .oraInizioFlow(context)
        .collectAsState(initial = 14 * 60)

    val oraFine by PreferenzeFiltro
        .oraFineFlow(context)
        .collectAsState(initial = 16 * 60)

    val lasciapassare by PreferenzeFiltro
        .lasciapassareFlow(context)
        .collectAsState(initial = emptyList())

    val blocchi by PreferenzeFiltro
        .blocchiFlow(context)
        .collectAsState(initial = emptyList())

    // ═══════════════════════════════════════════════
    // FOREGROUND SERVICE: SINCRONIZZAZIONE
    // ═══════════════════════════════════════════════
    // Ogni volta che `filtroAttivo` cambia, avviamo o fermiamo il servizio.
    // Il servizio possiede la notifica persistente (non swipe-abile).
    LaunchedEffect(filtroAttivo) {
        if (filtroAttivo) {
            FiltroForegroundService.avvia(context)
        } else {
            FiltroForegroundService.ferma(context)
        }
    }


    // ═══════════════════════════════════════════════
    // LAYOUT
    // ═══════════════════════════════════════════════
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(color = Color(0xFFDCE44E))
    ) {

        // ZONA 1: contenuto scorrevole
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // ───── Spazio dalla status bar ─────
            Spacer(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .height(24.dp)
            )

            // ═══════════════════════════════════════════════
            // RIGA: LOGO (centrato) + PULSANTE INFO (a destra)
            // ═══════════════════════════════════════════════
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Spacer fantasma a sinistra (per centrare il logo)
                Spacer(modifier = Modifier.size(42.dp))

                // Logo al centro
                Box(
                    contentAlignment = Alignment.Center,
                ) {
                    Image(
                        painter = painterResource(R.drawable.logo_app),
                        contentDescription = "Logo",
                        modifier = Modifier
                            .size(80.dp)
                    )
                }

                // Pulsante Info a destra
                IconButton(
                    onClick = onVaiAInfo,
                    modifier = Modifier
                        .size(42.dp)
                        .padding(4.dp)
                        .background(
                            color = Color(0xFF19A7A7),
                            shape = CircleShape)
                        .border(
                            width = 2.dp,
                            color = Color.White,
                            shape = CircleShape
                        )


                ) {
                    Icon(
                        imageVector = Icons.Filled.Info,
                        contentDescription = "Info",
                        tint = Color.White,
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ───── Titolo ─────
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center,
                color = colorResource(R.color.giallo_app),
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(vertical = 8.dp)
                    .background(
                        color = Color(0xFF19A7A7),
                        shape = RoundedCornerShape(16.dp)
                    )
                    .border(
                        width = 2.dp,
                        color = Color.White,
                        shape = RoundedCornerShape(16.dp)
                    )
            )
            Text(
                text = stringResource(R.string.info_name),
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Red,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .padding(top = 8.dp, bottom = 24.dp)
            )

            // ───── BANNER 1: app NON è filtro chiamate di sistema ─────
            if (!sonoAppScreening) {
                BannerAvvisoScreening(
                    onAttiva = {
                        val roleManager = try {
                            context.getSystemService(RoleManager::class.java)
                        } catch (_: Throwable) {
                            null
                        }
                        if (roleManager != null &&
                            roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)
                        ) {
                            val intent = roleManager.createRequestRoleIntent(
                                RoleManager.ROLE_CALL_SCREENING
                            )
                            launcherScreening.launch(intent)
                        }
                    }
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // ───── BANNER 2: permesso rubrica negato ─────
            if (!permessoConcesso) {
                BannerAvvisoPermesso(
                    onRichiedi = {
                        val activity = context as? Activity
                        val puoChiedereAncora = activity
                            ?.shouldShowRequestPermissionRationale(
                                Manifest.permission.READ_CONTACTS
                            ) ?: false

                        when {
                            puoChiedereAncora -> {
                                richiestaFatta = true
                                launcherPermesso.launch(Manifest.permission.READ_CONTACTS)
                            }
                            !richiestaFatta -> {
                                richiestaFatta = true
                                launcherPermesso.launch(Manifest.permission.READ_CONTACTS)
                            }
                            else -> {
                                val intent = Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                                ).apply {
                                    data = Uri.fromParts(
                                        "package",
                                        context.packageName,
                                        null
                                    )
                                }
                                launcherImpostazioni.launch(intent)
                            }
                        }
                    }
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            Spacer(modifier = Modifier.height(8.dp))

            // ───── Switch principale filtro ON/OFF ─────
            Switch(
                checked = filtroAttivo,
                onCheckedChange = { nuovoValore ->
                    scope.launch {
                        PreferenzeFiltro.setFiltroAttivo(context, nuovoValore)
                        if (!nuovoValore) {
                            // Filtro spento → azzera anche la programmazione
                            PreferenzeFiltro.setProgrammazioneAttiva(context, false)
                        }
                    }
                }
            )
            Text(
                text = if (filtroAttivo) "✅ Filtro ATTIVO" else "⭕ Filtro disattivato",
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp)
            )

            // ───── NOTA "24 ORE SU 24" ─────
            if (filtroAttivo && !programmazioneAttiva) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "⏱️  Il filtro agirà 24 ore su 24.\nUsa la Programmazione oraria per limitarlo a una fascia specifica.",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = Color(0xFF1F4E45),
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            color = Color(0xFFB8E0D8),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                )
            }

            // ═══════════════════════════════════════════════
            // SEZIONE PROGRAMMAZIONE ORARIA
            // ═══════════════════════════════════════════════
            if (filtroAttivo) {

                Spacer(modifier = Modifier.height(32.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Programmazione oraria",
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                    Switch(
                        checked = programmazioneAttiva,
                        onCheckedChange = { nuovoValore ->
                            scope.launch {
                                PreferenzeFiltro.setProgrammazioneAttiva(context, nuovoValore)
                            }
                        }
                    )
                }

                if (programmazioneAttiva) {
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Tutto il giorno",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(end = 12.dp)
                        )
                        Switch(
                            checked = tuttoIlGiorno,
                            onCheckedChange = { nuovoValore ->
                                scope.launch {
                                    PreferenzeFiltro.setTuttoIlGiorno(context, nuovoValore)
                                }
                            }
                        )
                    }

                    if (!tuttoIlGiorno) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OraPicker(
                                etichetta = "Dalle",
                                minutiCorrenti = oraInizio,
                                onOraSelezionata = { nuoviMinuti ->
                                    scope.launch {
                                        PreferenzeFiltro.setOraInizio(context, nuoviMinuti)
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                            OraPicker(
                                etichetta = "Alle",
                                minutiCorrenti = oraFine,
                                onOraSelezionata = { nuoviMinuti ->
                                    scope.launch {
                                        PreferenzeFiltro.setOraFine(context, nuoviMinuti)
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Il filtro agirà solo tra le ${formatOra(oraInizio)} e le ${formatOra(oraFine)}.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center
                        )
                    } else {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Il filtro agirà 24 ore su 24.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // ───── Pulsanti verso le schermate secondarie ─────
            Spacer(modifier = Modifier.height(32.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(24.dp))

            OutlinedButton(
                onClick = onVaiALasciapassare,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Numeri autorizzati (${lasciapassare.size})",
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "Vai"
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
                onClick = onVaiAlRegistro,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Chiamate bloccate (${blocchi.size})",
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "Vai"
                )
            }
        }

        // ZONA 2: footer fisso in fondo
        Text(
            text = stringResource(R.string.powered_by) ,
            style = MaterialTheme.typography.titleMedium,
            color = Color.Blue,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(vertical = 16.dp)
        )
    }
}


// ─────────────────────────────────────────────────────────────
// FUNZIONI DI SUPPORTO
// ─────────────────────────────────────────────────────────────

@Composable
private fun ricordaSeSonoAppScreening(context: Context): Boolean {
    var sonoScreening by remember {
        mutableStateOf(calcolaRuoloScreening(context))
    }
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                sonoScreening = calcolaRuoloScreening(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    return sonoScreening
}

private fun calcolaRuoloScreening(context: Context): Boolean {
    return try {
        val roleManager = context.getSystemService(RoleManager::class.java)
        roleManager?.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) == true
    } catch (_: Throwable) {
        false
    }
}

@Composable
private fun BannerAvvisoScreening(onAttiva: () -> Unit) {
    val nomeApp = stringResource(R.string.app_name)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = Color(0xFFA87D7D),
                shape = RoundedCornerShape(12.dp)
            )
            .padding(16.dp)
    ) {
        Text(
            text = stringResource(R.string.screening_a),
            style = MaterialTheme.typography.titleMedium,
            color = Color(0xFFB00020),
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = buildAnnotatedString {
                append(stringResource(R.string.screening_b))
                withStyle(
                    SpanStyle(
                        fontWeight = FontWeight.Bold,
                        color = (colorResource(R.color.giallo_app))
                    )
                ) {
                    append(nomeApp)
                }
                append(stringResource(R.string.screening_b1))
            },
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFFB00020)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Button(
            onClick = onAttiva,
            modifier = Modifier
                .height(42.dp)
                .align(Alignment.CenterHorizontally),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00B8D4),
                    contentColor = Color.White
                ),
            border = BorderStroke(
                            width = 2.dp,
                            color = colorResource(R.color.giallo_app)),
                            shape = RoundedCornerShape(16.dp)
                        )
        {
            Text(
                text = "Attiva ora",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = colorResource(R.color.giallo_app),
            )

            Spacer(modifier = Modifier
                .width(5.dp))
            Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = null,
                tint = colorResource(R.color.giallo_app),
                modifier = Modifier
                    .size(18.dp),
            )
        }

    }
}
@Composable
private fun BannerAvvisoPermesso(onRichiedi: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = Color(0xFFFFF3E0),
                shape = RoundedCornerShape(12.dp)
            )
            .padding(16.dp)
    ) {
        Text(
            text = "⚠️  Permesso contatti negato",
            style = MaterialTheme.typography.titleMedium,
            color = Color(0xFFE65100),
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Senza accesso ai contatti, il filtro non può distinguere i tuoi contatti dallo spam. Concedi il permesso per farlo funzionare.",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFFE65100)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Button(
            onClick = onRichiedi,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Concedi permesso")
        }
    }
}

@Composable
fun OraPicker(
    etichetta: String,
    minutiCorrenti: Int,
    onOraSelezionata: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Button(
        onClick = {
            val hh = minutiCorrenti / 60
            val mm = minutiCorrenti % 60

            TimePickerDialog(
                context,
                { _, oraScelta, minutoScelto ->
                    onOraSelezionata(oraScelta * 60 + minutoScelto)
                },
                hh,
                mm,
                true
            ).show()
        },
        modifier = modifier
    ) {
        Text(
            text = "$etichetta: ${formatOra(minutiCorrenti)}",
            textAlign = TextAlign.Center
        )
    }
}

fun formatOra(minuti: Int): String {
    val hh = (minuti / 60).toString().padStart(2, '0')
    val mm = (minuti % 60).toString().padStart(2, '0')
    return "$hh:$mm"
}


// ─────────────────────────────────────────────────────────────
// PREVIEW
// ─────────────────────────────────────────────────────────────

@Preview(showBackground = true, name = "Home")
@Composable
fun SchermataHomePreview() {
    RelaxTheme {
        SchermataHome(
            onVaiALasciapassare = {},
            onVaiAlRegistro = {},
            onVaiAInfo = {}
        )
    }
}

@Preview(showBackground = true, name = "Ora Picker")
@Composable
fun OraPickerPreview() {
    RelaxTheme {
        OraPicker(
            etichetta = "Dalle",
            minutiCorrenti = 14 * 60,
            onOraSelezionata = {}
        )
    }
}