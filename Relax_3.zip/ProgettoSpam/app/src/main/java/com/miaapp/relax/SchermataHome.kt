package com.miaapp.relax

// ─────────────────────────────────────────────────────────────
// IMPORT
// ─────────────────────────────────────────────────────────────

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings

import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

import androidx.core.content.ContextCompat

import com.miaapp.relax.ui.theme.RelaxTheme
import kotlinx.coroutines.launch


// ─────────────────────────────────────────────────────────────
// SCHERMATA HOME
// ─────────────────────────────────────────────────────────────

@Composable
fun SchermataHome(
    onVaiALasciapassare: () -> Unit,
    onVaiAlRegistro: () -> Unit,
    onVaiAInfo: () -> Unit,
    onVaiAProgrammazione: () -> Unit,
    // 🧪 TEMPORANEO: parametro per il test animazione. RIMUOVERE IN PRODUZIONE
    onVaiATestAnimazione: () -> Unit
    // 🧪 FINE BLOCCO TEMPORANEO
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // ═══════════════════════════════════════════════
    // PERMESSO RUBRICA + NOTIFICHE
    // ═══════════════════════════════════════════════
    var permessoConcesso by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_CONTACTS
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    var richiestaFatta by remember { mutableStateOf(false) }

    val launcherNotifiche = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { }

    val launcherPermesso = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { concesso ->
        permessoConcesso = concesso
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permessoNotifiche = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!permessoNotifiche) {
                launcherNotifiche.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val launcherImpostazioni = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { }

    LaunchedEffect(Unit) {
        if (!permessoConcesso && !richiestaFatta) {
            richiestaFatta = true
            launcherPermesso.launch(Manifest.permission.READ_CONTACTS)
        }
    }

    // ═══════════════════════════════════════════════
    // RUOLO DI SCREENING
    // ═══════════════════════════════════════════════
    val sonoAppScreening = ricordaSeSonoAppScreening(context)

    val launcherScreening = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { }

    // ═══════════════════════════════════════════════
    // LIFECYCLE
    // ═══════════════════════════════════════════════
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permessoConcesso = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_CONTACTS
                ) == PackageManager.PERMISSION_GRANTED
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // ═══════════════════════════════════════════════
    // STATI PREFERENZE
    // ═══════════════════════════════════════════════
    val filtroAttivo by PreferenzeFiltro
        .filtroAttivoFlow(context)
        .collectAsState(initial = false)

    val programmazioneAttiva by PreferenzeFiltro
        .programmazioneAttivaFlow(context)
        .collectAsState(initial = false)

    val lasciapassare by PreferenzeFiltro
        .lasciapassareFlow(context)
        .collectAsState(initial = emptyList())

    val blocchi by PreferenzeFiltro
        .blocchiFlow(context)
        .collectAsState(initial = emptyList())

    // ═══════════════════════════════════════════════
    // FOREGROUND SERVICE
    // ═══════════════════════════════════════════════
    LaunchedEffect(filtroAttivo) {
        if (filtroAttivo) {
            FiltroForegroundService.avvia(context)
        } else {
            FiltroForegroundService.ferma(context)
        }
    }

    // ═══════════════════════════════════════════════
    // LAYOUT
    // ═══════════════════════════════════════════════
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(color = colorResource(R.color.giallo_app))
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .height(24.dp)
            )

            // RIGA: LOGO + INFO
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Spacer(modifier = Modifier.size(42.dp))

                Box(contentAlignment = Alignment.Center) {
                    Image(
                        painter = painterResource(R.drawable.logo_app),
                        contentDescription = "Logo",
                        modifier = Modifier.size(80.dp)
                    )
                }

                IconButton(
                    onClick = onVaiAInfo,
                    modifier = Modifier
                        .size(42.dp)
                        .padding(4.dp)
                        .background(
                            color = colorResource(R.color.turchese),
                            shape = CircleShape
                        )
                        .border(
                            width = 2.dp,
                            color = colorResource(R.color.white),
                            shape = CircleShape
                        )
                ) {
                    Icon(
                        imageVector = Icons.Filled.Info,
                        contentDescription = "Info",
                        tint = colorResource(R.color.white)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Titolo
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center,
                color = colorResource(R.color.giallo_app),
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(vertical = 8.dp)
                    .background(
                        color = colorResource(R.color.turchese),
                        shape = RoundedCornerShape(16.dp)
                    )
                    .border(
                        width = 2.dp,
                        color = colorResource(R.color.white),
                        shape = RoundedCornerShape(16.dp)
                    )
            )
            Text(
                text = stringResource(R.string.info_name),
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Red,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp, bottom = 24.dp)
            )

            // BANNER 1
            if (!sonoAppScreening) {
                BannerAvvisoScreening(
                    onAttiva = {
                        val roleManager = try {
                            context.getSystemService(RoleManager::class.java)
                        } catch (_: Throwable) {
                            null
                        }
                        if (roleManager != null &&
                            roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)
                        ) {
                            val intent = roleManager.createRequestRoleIntent(
                                RoleManager.ROLE_CALL_SCREENING
                            )
                            launcherScreening.launch(intent)
                        }
                    }
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // BANNER 2
            if (!permessoConcesso) {
                BannerAvvisoPermesso(
                    onRichiedi = {
                        val activity = context as? Activity
                        val puoChiedereAncora = activity
                            ?.shouldShowRequestPermissionRationale(
                                Manifest.permission.READ_CONTACTS
                            ) ?: false

                        when {
                            puoChiedereAncora -> {
                                richiestaFatta = true
                                launcherPermesso.launch(Manifest.permission.READ_CONTACTS)
                            }
                            !richiestaFatta -> {
                                richiestaFatta = true
                                launcherPermesso.launch(Manifest.permission.READ_CONTACTS)
                            }
                            else -> {
                                val intent = Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                                ).apply {
                                    data = Uri.fromParts("package", context.packageName, null)
                                }
                                launcherImpostazioni.launch(intent)
                            }
                        }
                    }
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            Spacer(modifier = Modifier.height(8.dp))

            // SWITCH PRINCIPALE
            Switch(
                checked = filtroAttivo,
                onCheckedChange = { nuovoValore ->
                    scope.launch {
                        PreferenzeFiltro.setFiltroAttivo(context, nuovoValore)
                        if (!nuovoValore) {
                            PreferenzeFiltro.setProgrammazioneAttiva(context, false)
                        }
                    }
                }
            )
            Text(
                text = if (filtroAttivo) "✅ Filtro ATTIVO" else "⭕ Filtro disattivato",
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp)
            )

            // NOTA 24 ORE
            if (filtroAttivo && !programmazioneAttiva) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "⏱️  Il filtro attivo h 24.\nUsa \"Programmazione oraria\".",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = colorResource(R.color.testo_titolo_card),
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            color = colorResource(R.color.card_verde),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                )
            }

            // PULSANTI VERSO ALTRE SCHERMATE
            Spacer(modifier = Modifier.height(32.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(24.dp))

            // Pulsante Programmazione oraria
            OutlinedButton(
                onClick = onVaiAProgrammazione,
                enabled = filtroAttivo,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = when {
                        !filtroAttivo -> "⏱️ Attiva il filtro"
                        programmazioneAttiva -> "⏱️ Programmazione attivata"
                        else -> "⏱️ Programmazione oraria"
                    },
                    color = when {
                        !filtroAttivo -> colorResource(R.color.testo_grigio)
                        programmazioneAttiva -> colorResource(R.color.turchese)
                        else -> colorResource(R.color.testo_scuro)
                    },
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "Vai"
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Pulsante Numeri autorizzati
            OutlinedButton(
                onClick = onVaiALasciapassare,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Numeri autorizzati (${lasciapassare.size})",
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "Vai"
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Pulsante Chiamate bloccate
            OutlinedButton(
                onClick = onVaiAlRegistro,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Chiamate bloccate (${blocchi.size})",
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "Vai"
                )
            }

            // 🧪 TEMPORANEO: pulsante per il test animazione. RIMUOVERE IN PRODUZIONE
            Spacer(modifier = Modifier.height(24.dp))
            OutlinedButton(
                onClick = onVaiATestAnimazione,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFF673AB7)   // viola, per distinguerlo
                )
            ) {
                Text(
                    text = "🧪 Test animazione (provvisorio)",
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "Vai"
                )
            }
            // 🧪 FINE BLOCCO TEMPORANEO
        }

        // FOOTER
        Text(
            text = stringResource(R.string.powered_by),
            style = MaterialTheme.typography.titleMedium,
            color = colorResource(R.color.turchese),
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(vertical = 16.dp)
        )
    }
}


// ─────────────────────────────────────────────────────────────
// FUNZIONI DI SUPPORTO
// ─────────────────────────────────────────────────────────────

@Composable
private fun ricordaSeSonoAppScreening(context: Context): Boolean {
    var sonoScreening by remember {
        mutableStateOf(calcolaRuoloScreening(context))
    }
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                sonoScreening = calcolaRuoloScreening(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    return sonoScreening
}

private fun calcolaRuoloScreening(context: Context): Boolean {
    return try {
        val roleManager = context.getSystemService(RoleManager::class.java)
        roleManager?.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) == true
    } catch (_: Throwable) {
        false
    }
}

@Composable
private fun BannerAvvisoScreening(onAttiva: () -> Unit) {
    val nomeApp = stringResource(R.string.app_name)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = colorResource(R.color.banner_screening_bg),
                shape = RoundedCornerShape(12.dp)
            )
            .padding(16.dp)
    ) {
        Text(
            text = stringResource(R.string.screening_a),
            style = MaterialTheme.typography.titleMedium,
            color = colorResource(R.color.banner_screening_testo),
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = buildAnnotatedString {
                append(stringResource(R.string.screening_b))
                withStyle(
                    SpanStyle(
                        fontWeight = FontWeight.Bold,
                        color = colorResource(R.color.giallo_app)
                    )
                ) {
                    append(nomeApp)
                }
                append(stringResource(R.string.screening_b1))
            },
            style = MaterialTheme.typography.bodySmall,
            color = colorResource(R.color.banner_screening_testo)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Button(
            onClick = onAttiva,
            modifier = Modifier
                .height(42.dp)
                .align(Alignment.CenterHorizontally),
            colors = ButtonDefaults.buttonColors(
                containerColor = colorResource(R.color.banner_pulsante_bg),
                contentColor = colorResource(R.color.white)
            ),
            border = BorderStroke(
                width = 2.dp,
                color = colorResource(R.color.giallo_app)
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(
                text = "Attiva ora",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = colorResource(R.color.giallo_app)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = null,
                tint = colorResource(R.color.giallo_app),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun BannerAvvisoPermesso(onRichiedi: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = colorResource(R.color.banner_permesso_bg),
                shape = RoundedCornerShape(12.dp)
            )
            .padding(16.dp)
    ) {
        Text(
            text = "⚠️  Permesso contatti negato",
            style = MaterialTheme.typography.titleMedium,
            color = colorResource(R.color.banner_permesso_testo),
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Senza accesso ai contatti, il filtro non può distinguere i tuoi contatti dallo spam. Concedi il permesso per farlo funzionare.",
            style = MaterialTheme.typography.bodySmall,
            color = colorResource(R.color.banner_permesso_testo)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Button(
            onClick = onRichiedi,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Concedi permesso")
        }
    }
}

fun formatOra(minuti: Int): String {
    val hh = (minuti / 60).toString().padStart(2, '0')
    val mm = (minuti % 60).toString().padStart(2, '0')
    return "$hh:$mm"
}


// ─────────────────────────────────────────────────────────────
// PREVIEW
// ─────────────────────────────────────────────────────────────

@Preview(showBackground = true, name = "Home")
@Composable
fun SchermataHomePreview() {
    RelaxTheme {
        SchermataHome(
            onVaiALasciapassare = {},
            onVaiAlRegistro = {},
            onVaiAInfo = {},
            onVaiAProgrammazione = {},
            // 🧪 TEMPORANEO: callback vuota per la preview. RIMUOVERE IN PRODUZIONE
            onVaiATestAnimazione = {}
            // 🧪 FINE BLOCCO TEMPORANEO
        )
    }
}