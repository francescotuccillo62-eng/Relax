package com.miaapp.relax

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.time.Duration.Companion.milliseconds

@Composable
fun SchermataTestAnimazione() {
    var replayCount by remember { mutableIntStateOf(0) }
    var sombreroSpostato by remember { mutableStateOf(false) }

    // Logica animazione
    LaunchedEffect(replayCount) {
        sombreroSpostato = false
        delay(2000.milliseconds) //tempo prima di iniziare l'animazione
        sombreroSpostato = true
    }
    // Valori X : 0.dp centro orizzontale;
    //numero positivo a destra;
    //numero negativo a sinistra.
    // Valori Y : 0.dp centro verticale;
    //Numero positivo in basso;
    //Numero negativo in alto.
    //Rotazione : 0f dritto;
    //Numero positivo a destra;
    //Numero negativo a sinistra.
    // ─── OFFSET X (Spostamento Orizzontale) ───
    val offsetX by animateDpAsState(
        // Se VERO (animazione FINITA -> valore if) -> 0.dp (centro)
        // Se FALSO (PARTENZA-> valore else) -> 70.dp (spostato a destra)
        targetValue = if (sombreroSpostato) (65.dp) else (0).dp,
        animationSpec = tween(durationMillis = 1000), //durata animazione (deve essere uguale a Y)
        label = "offsetX"
    )

    // ─── OFFSET Y (Spostamento Verticale) ───
    val offsetY by animateDpAsState(
        // Se VERO (animazione finita -> valore if) -70.dp (più in alto)
        // Se FALSO (partenza)(valore else) -> -90.dp (leggermente più in basso)
        targetValue = if (sombreroSpostato) (-50).dp else (-76).dp,
        animationSpec = tween(durationMillis = 1000), //durata animazione (deve essere uguale a X)
        label = "offsetY"
    )

    // ─── ROTAZIONE ───
    val rotazione by animateFloatAsState(
        // Se VERO (animazione finita) -> 0f (Orizzontale, dritto)
        // Se FALSO (partenza) -> 30f (Inclinato verso DESTRA)
        targetValue = if (sombreroSpostato) (35f) else (0f),
        animationSpec = tween(durationMillis = 800),
        label = "rotazione"
    )


    // L'UNICA COLONNA. Niente di strano.
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally // Tutto centrato orizzontalmente
    ) {
        Spacer(modifier = Modifier.height(30.dp))
        // 1. LOGO 1
        Image(
            painter = painterResource(R.drawable.logo_app),
            contentDescription = "Logo 1",
            modifier = Modifier.size(80.dp)
        )
        Text(
            text = "Logo di partenza",
            color = colorResource(R.color.giallo_app)
        )
        Spacer(modifier = Modifier.height(30.dp))

        // 2. LOGO 2
        Image(
            painter = painterResource(R.drawable.logo_app_on),
            contentDescription = "Logo 2",
            modifier = Modifier.size(80.dp)
        )
        Text(
            text = "Logo di arrivo",
            color = colorResource(R.color.giallo_app)
        )
        Spacer(modifier = Modifier.height(60.dp))

        // 3. ANIMAZIONE (Scudo + Sombrero)
        Box(
            modifier = Modifier.size(200.dp, 180.dp),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(R.drawable.logo_scudo),
                contentDescription = "Scudo",
                modifier = Modifier.size(120.dp, 140.dp)
            )
            Image(
                painter = painterResource(R.drawable.logo_sombrero),
                contentDescription = "Sombrero",
                modifier = Modifier
                    .size(125.dp, 90.dp)
                    .offset { IntOffset(offsetX.roundToPx(), offsetY.roundToPx()) }
                    .rotate(rotazione)
            )
        }
        Text(
            text = "Animazione",
            color = colorResource(R.color.giallo_app)
        )
        Spacer(modifier = Modifier.height(170.dp))

        // 4. PULSANTE
        OutlinedButton(
            onClick = { replayCount++ },
            modifier = Modifier
                .fillMaxWidth()
        ) {
            Text("🔁 Clicca qui per far ripartire")
        }

        // Spazio finale per non far toccare il pulsante col bordo (opzionale)
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Preview(showBackground = true, name = "Test Animazione")
@Composable
fun TestAnimazionePreview() {
    SchermataTestAnimazione()
}