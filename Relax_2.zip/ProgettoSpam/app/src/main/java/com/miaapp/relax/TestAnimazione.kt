package com.miaapp.relax

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.time.Duration.Companion.milliseconds

@Composable
fun LogoAnimato() {
    // ── Stato dell'animazione ──
    // false = sombrero a destra, inclinato (partenza)
    // true = sombrero centrato, in alto, orizzontale (arrivo)
    var sombreroSpostato by remember { mutableStateOf(false) }

    // ── Avvia l'animazione dopo un piccolo delay ──
    LaunchedEffect(Unit) {
        delay(300.milliseconds)     // 👈 versione moderna
        sombreroSpostato = true     // 👈 avvia l'animazione
    }

    // ── Offset del sombrero (x, y) ──
    // Partenza (sombreroSpostato=false): a destra, inclinato → (90, -80)
    // Arrivo (sombreroSpostato=true): centrato, in alto → (0, -110)
    val offsetX by animateDpAsState(
        targetValue = if (sombreroSpostato) 0.dp else 90.dp,
        animationSpec = tween(durationMillis = 800),
        label = "offsetX"
    )
    val offsetY by animateDpAsState(
        targetValue = if (sombreroSpostato) (-110).dp else (-80).dp,
        animationSpec = tween(durationMillis = 800),
        label = "offsetY"
    )

    // ── Rotazione del sombrero ──
    // Partenza: -30° (inclinato), Arrivo: 0° (orizzontale)
    val rotazione by animateFloatAsState(
        targetValue = if (sombreroSpostato) 0f else (-30f),
        animationSpec = tween(durationMillis = 800),
        label = "rotazione"
    )

    // ── Layout ──
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        // Scudo al centro (rimane fermo)
        Image(
            painter = painterResource(id = R.drawable.logo_scudo),
            contentDescription = "Scudo",
            modifier = Modifier.size(200.dp, 240.dp)
        )

        // Sombrero: parte a destra inclinato, arriva centrato orizzontale
        Image(
            painter = painterResource(id = R.drawable.sombreo_diagonale),
            contentDescription = "Sombrero",
            modifier = Modifier
                .size(230.dp, 130.dp)
                .offset { IntOffset(offsetX.roundToPx(), offsetY.roundToPx()) }   // 👈 versione moderna
                .rotate(rotazione)
        )
    }
}

// ─────────────────────────────────────────────────────────────
// PREVIEW
// ─────────────────────────────────────────────────────────────

@Preview(showBackground = true, name = "Logo Animato")
@Composable
fun LogoAnimatoPreview() {
    LogoAnimato()
}